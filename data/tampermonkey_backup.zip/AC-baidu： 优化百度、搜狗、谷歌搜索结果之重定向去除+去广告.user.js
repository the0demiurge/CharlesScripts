// ==UserScript==
// @name AC-baidu： 优化百度、搜狗、谷歌搜索结果之重定向去除+去广告
// @icon            https://coding.net/u/zb227/p/zbImg/git/raw/master/img0/icon.jpg
// @grant		    GM_xmlhttpRequest
// @author          AC
// @create          2015-11-25
// @run-at          document-start
// @version         9.2
// @connect         *
// @include         http://www.baidu.com/*
// @include         https://www.baidu.com/*
// @include         http://www.sogou.com/*
// @include         https://www.sogou.com/*
// @include         /^https?\:\/\/encrypted.google.[^\/]+/
// @include         /^https?\:\/\/www.google.[^\/]+/
// @include         https://*.zhidao.baidu.com/*
// @include         https://zhidao.baidu.com/*
// @home-url        https://greasyfork.org/zh-TW/scripts/14178
// @namespace       1353464539@qq.com
// @copyright       2017, AC
// @description     1.繞過百度、搜狗搜索結果中的自己的跳轉鏈接，直接訪問原始網頁-反正都能看懂 2.去除百度的多余广告
// @lastmodified    2017-05-12
// @feedback-url    https://greasyfork.org/zh-TW/scripts/14178
// @note            2017.05.12-V9.2 暂时移除谷歌的安全搜索模式，因为很复杂的原因
// @note            2017.05.12-V9.1 暂时移除Favicon的显示，因为这样就杂了，有需要的人自己去装这个脚本吧，保留百度去广告
// @note            2017.05.12-V9.0 集合了去重定向+去广告+Favicon显示
// @note            2017.05.12-V8.7 集合了去广告的脚本，以前的那个去广告的脚本就不用了
// @note            2017.05.12-V8.6 修复谷歌安全搜索的BUG V2
// @note            2017.05.12-V8.4 新增：默认屏蔽谷歌的安全搜索功能
// @note            2017.05.05-V8.3 修复include范围太小导致的百度知道的屏蔽问题
// @note            2017.05.04-V8.2 终于修复了百度知道图片替换了文字的这个大BUG; 顺便处理了superapi.zhidao.baidu.com; 新增谷歌搜索结果重定向去除
// @note            2017.05.04-V8.1 终于修复了百度知道图片替换了文字的这个大BUG，顺便处理了superapi.zhidao.baidu.com
// @note            2017.05.04-V8.0 终于修复了百度知道图片替换了文字的这个大BUG，待测试
// @note            2017.03.28-V7.6 修复在ViolentMonkey上的不支持的问题
// @note            2017.03.28-V7.5 尝试修复chrome上的问题
// @note            2017.03.21-V7.4 尝试处理Edge上不支持的问题，结果发现是Edge本身的TamperMonkey支持有问题
// @note            2017.03.19-V7.3 修复打开百度之后再次点击“百度一下”导致的无法更新重定向问题
// @note            2017.03.19-V7.2 未知原因chrome的MutationObserver无法使用了，继续回归以前的DOMNodeInserted
// @note            2017.02.17-V7.0 修复搜狗的搜索结果重定向问题+改个名字
// @note            2017.02.17-V6.9 修复搜狗的搜索结果重定向问题
// @note            2016.12.10-V6.8 ***
// @note            2016.10.27-V6.7 修复了以前的重复请求，现在的请求数应该小了很多，网络也就不卡了，感觉萌萌哒
// @note            2016.04.24-V6.6 恢复以前的版本，因为兼容性问题
// @note            2015.12.01-V5.0 加入搜狗的支持，但是支出不是很好
// @note            2015.11.25-V2.0 优化，已经是真实地址的不再尝试获取
// @note            2015.11.25-V1.0 完成去掉百度重定向的功能
// ==/UserScript==

// 采用MutationObserver监视会大大实际代码的调用次数-比DOMNodeInserted更好的调用方式
(function(){
    var Stype; // 去重定向的选择
    var Ftype; // favicon的选择
    if (location.host == "www.baidu.com") {
        Stype = "h3.t>a";
        Ftype = ".c-showurl,a.texttolink";
    } else if (location.host == "sogou.com") {
        Stype = "h3.pt>a, h3.vrTitle>a";
        Ftype = "cite[id*='cacheresult_info_']";
    } else if (location.host.indexOf("google") > -1){
        Stype = "h3>a";
        Ftype = "._Rm";
        //if (location.host.indexOf("google") > -1){
        //    var oldHref = location.href;
        //    if(location.href.indexOf("safe=") < 0){
        //        if(location.host == oldHref || oldHref.charAt(oldHref.length-1)=='/'){
        //            oldHref = oldHref + "?safe=off";
        //        }else{
        //            oldHref = oldHref + "&safe=off";
        //        }
        //    }else if(location.href.indexOf("safe=off") < 0){
        //        oldHref = oldHref.replace(/&safe=[^&]+/, "safe=off");
        //    }
        //    oldHref = oldHref.replace("https://www.google.com.hk/", "https://www.google.co.jp/");
        //    if(location.href != oldHref)
        //        location.href = oldHref;
        //}
    } else {
        //console.log("i'am in");
        addStyle(".word-replace{display: none  !important;}");
        return;
    }
    document.addEventListener("DOMNodeInserted", function(event){
        var element = event.target;
        removeOnMouseDownFunc();
        removeSafeSearch_google();
        removeAD_baidu();
        resetURL(document.querySelectorAll(Stype));
    });
    function removeOnMouseDownFunc(){
        try{
            document.querySelectorAll(".g .rc .r a").forEach(function(one){
               one.setAttribute("onmousedown", "");
            });
        }catch(e){}
    }
    function removeSafeSearch_google(){
        try{
            document.querySelector("input[name='safe']").value="off";
        }catch(e){}
    }
    function addStyle(css) { //添加CSS的代码--copy的
        var pi = document.createProcessingInstruction(
            'xml-stylesheet',
            'type="text/css" href="data:text/css;utf-8,' + encodeURIComponent(css) + '"'
        );
        return document.insertBefore(pi, document.documentElement);
    }
    function resetURL(list){
        for(var i = 0; i < list.length; i++){
            // 此方法是异步，故在结束的时候使用i会出问题-严重!
            // 采用闭包的方法来进行数据的传递
            var curhref = list[i].href;
            if(list[i].getAttribute("ac_redirectStatus") == null){
                list[i].setAttribute("ac_redirectStatus", "0");
                if(curhref.indexOf("baidu.com") > -1 || curhref.indexOf("sogou.com") > -1){
                  (function(c_curhref){
                    GM_xmlhttpRequest({
                            url: c_curhref,
                            headers: {
                                "Accept": "text/html"
                            },
                            method: "GET",
                            onreadystatechange:function(response) {
                                if(response.status==200){
                                    DealResult(response, c_curhref);
                                }
                            }
                    });
                  })(curhref); //传递旧的网址过去，读作c_curhref
                }else if(curhref.indexOf("/interstitial") > -1){
                    
                }else{
                    //console.log("绕过百度重定向直接访问网页： 第"+i+"个已经处理了");
                }
            }
        }
    }
    function DealResult(response, c_curhref){
        var resultURL = response.finalUrl;
        if(Stype.length > 10){
            //如果是搜狗的结果
            var resultResponseUrl = Reg_Get(response.responseText, "URL='([^']+)'");
            if(resultResponseUrl !== null)
                resultURL = resultResponseUrl;
        }
        var indexhref = Reg_Get(c_curhref, "((?:http)[^&]+)");// 必须要提取部分数据，因为之后的莫名加了其他参数ck=0.0.0.0.....
        var ccnode = document.querySelectorAll("h3>[href*='"+indexhref+"']")[0];
        if(ccnode != null){
            ccnode.href = resultURL;
        }else{
            console.log("该链接已经被其他脚本干掉了哦"+resultURL);
        }
    }
    function Reg_Get(HTML, reg){
        var RegE = new RegExp(reg);
        return RegE.exec(HTML)[1];
    }
    function removeAD_baidu(){
        if(location.host == "www.baidu.com"){
            var no = document.getElementById("content_right");
            if(no != null) no.remove();
            if(document.querySelectorAll("#content_left")[0] != null){
                var fathers = document.querySelectorAll("#content_left")[0].childNodes;
                var lastId = 0;
                for(var i = 0; i < fathers.length; i++){
                    var currentNode = fathers[i];
                    if(fathers[i].tagName=="DIV" && fathers[i].getAttribute("dealAD") == null){
                        if(null == currentNode.id || "" == currentNode.id){
                            // 米有ID的貌似都是广告
                            console.log("移除 CLASS="+currentNode.className);
                            currentNode.remove();
                        } else if(currentNode.id == "clone"){
                            // ID 显示为CLONE的也是广告
                            console.log("移除 ID="+currentNode.id);
                            currentNode.remove();
                        } else if(currentNode.className.indexOf("result") != 0 && /^\d+$/.test(currentNode.id)){
                            // class不是result...的，并且id是纯粹数字的(很大)
                            console.log("移除 ID="+currentNode.id);
                            currentNode.remove();
                        } else{
                            var node = currentNode.querySelectorAll(".f13>span")[0];
                            if(node != null && node.innerHTML == "广告"){
                                console.log("移除 ID="+currentNode.id);
                                currentNode.remove();
                            }
                            //document.querySelectorAll("#content_left>div[id='"+ currentNode.id +"']")[0].remove();
                        }
                        currentNode.setAttribute("dealAD", 1);
                    }
                }
            }
        }
    }
})();