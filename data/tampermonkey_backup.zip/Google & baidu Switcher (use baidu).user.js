// ==UserScript==
// @name      Google & baidu Switcher (use baidu)
// @namespace  https://openuserjs.org/scripts/t3xtf0rm4tgmail.com/Google_baidu_Switcher_(use_baidu)
// @author    F9y4ng
// @version    1.2.5.2
// @description  在百度的搜索结果页面增加google搜索跳转按钮，不懂跳墙使用GOOGLE的同学请自动忽略。
// @include        http://www.baidu.com/*
// @include        https://www.baidu.com/*
// @include        http://baidu.com/*
// @include        https://baidu.com/*
// @license        MPL
// @copyright      2015+, f9y4ng
// @grant          none
// ==/UserScript==


$(document).ready(function() {

    function baiduswitchgoogle() {
        $('.s_btn_wr').after('<div class="s_btn_wr bg" style="display:inline-block;margin-left:10px"><input type="button" id="ggyx" value="Google一下" class="bg s_btn" ></div>');
        $('#ggyx').on({
            click: function () {
                window.open("https://www.google.com.hk/webhp?gws_rd=ssl#newwindow=1&hl=zh-CN&q=" + encodeURIComponent($('#kw') .val()));
                return false;
            }
        });
    }

    if(window.location.search.lastIndexOf("wd=")>0){
        baiduswitchgoogle();
    }

    //检测从baidu首页进入的搜索（补漏）
    if(/^http(s)?:\/\/(www\.)?baidu\.com\/$/ig.test(window.location.href)){
        $("#kw").off('click').on({
            keydown: function () {
                if($('#ggyx').length<1 && $('#kw').val().length>0){baiduswitchgoogle();}
            }
        }).on({
             paste: function () {
                if($('#ggyx').length<1){baiduswitchgoogle();}
            }
        });
    }

});