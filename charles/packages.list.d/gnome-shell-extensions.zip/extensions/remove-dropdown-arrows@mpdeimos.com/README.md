Remove Dropdown Arrows Gnome Shell Extension
============================================

Removes the dropdown arrows which were introduced in Gnome 3.10 from the App Menu, System Menu, Input Menu, Access Menu, Places Menu, Applications Menu and any other extension that wants to add dropdown arrows.

![Screenshot](screenshot.png)

[![Build Status](https://travis-ci.org/mpdeimos/gnome-shell-remove-dropdown-arrows.svg?branch=master)](https://travis-ci.org/mpdeimos/gnome-shell-remove-dropdown-arrows)
