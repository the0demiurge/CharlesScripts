// ==UserScript==
// @name         拒绝二维码登录（淘宝、京东等网站默认出现账号密码登录界面）
// @namespace    undefined
// @version      0.1.7
// @description  淘宝、京东、阿里云等网站默认使用账号密码登录，不出现二维码登录界面
// @author       Vizards
// @match        *://login.taobao.com/*
// @match        *://login.1688.com/*
// @match        *://account.aliyun.com/*
// @match        *://passport.jd.com/*
// @match        *://weibo.com/*
// @match        *://login.tmall.com/*
// @match        *://pan.baidu.com/*
// @match        *://graph.qq.com/*
// @match        *://xui.ptlogin2.qq.com/*
// @match        *://ssl.xui.ptlogin2.qq.com/*
// @grant        none
// ==/UserScript==

/**
 * login.taobao.com/*
 * login.1688.com/*
 * login.tmall.com/*
 */

if (location.hostname === 'login.taobao.com') {
   var auto = setInterval(function() {
       if (window.getComputedStyle(document.getElementById('J_StaticForm')).display === 'none') {
           document.getElementById('J_Quick2Static').click();
           clearInterval(auto);
       }
   }, 50);
}

// passport.jd.com/*
if (location.hostname === 'passport.jd.com') {
   var auto = setInterval(function() {
       if (document.getElementsByClassName('login-box')[0].style.display === 'none') {
           document.getElementsByClassName('login-tab-r')[0].click();
           clearInterval(auto);
       }
   }, 50);
}

// account.aliyun.com/*
if (location.hostname === 'account.aliyun.com') {
	miniLoginEmbedder.init({
	    targetId: 'alibaba-login-iframe',
	    appName: 'aliyun',
	    appEntrance: 'aliyun',
	    iframeUrl: 'https://passport.alibaba.com/mini_login.htm',
	    lang: 'zh_CN',
	    notLoadSsoView: '',
	    notKeepLogin: 'true',
	    loginId: '',
	    iframeHeight: '305px',
	    queryStr: '&regUrl=https%3A%2F%2Faccount.aliyun.com%2Fregister%2Fregister.htm%3Foauth_callback%3Dhttps%253A%252F%252Fcn.aliyun.com%252F&qrCodeFirst=false'
	});

	setInterval(function () {
	    document.getElementById('alibaba-login-iframe').getElementsByTagName('iframe')[0].style.display = 'none';
	    document.getElementById('alibaba-login-iframe').getElementsByTagName('iframe')[1].height = '320';
	    document.getElementsByClassName('agreement')[0].style.bottom = '-25px';
	},50);
}

// weibo.com/*
// pan.baidu.com/*
if (location.hostname === 'weibo.com') {
    var auto = setInterval(function() {
        if (document.getElementsByClassName('W_login_form')[0].style.display === 'none') {
            document.getElementsByClassName('W_fb')[0].click();
            clearInterval(auto);
        }
    }, 50);
}

if (location.hostname === 'pan.baidu.com') {
    var auto = setInterval(function() {
        if (document.getElementsByClassName('qcode-title')[0].getAttribute("class") === "qcode-title active") {
            document.getElementsByClassName("account-title")[0].getElementsByTagName('a')[0].click();
            clearInterval(auto);
        }
    }, 50);
}

// graph.qq.com/*
// xui.ptlogin2.qq.com/*
if (location.hostname === 'xui.ptlogin2.qq.com' || location.hostname === 'ssl.xui.ptlogin2.qq.com') {
    var auto = setInterval(function() {
        if (document.getElementsByClassName('face').length <= 1 && document.getElementById('qlogin').style.display === 'block') {
            document.getElementById('switcher_plogin').click();
            clearInterval(auto);
        }
    }, 50);
}

window.onload = function () {
	if (location.hostname === 'graph.qq.com') {
		document.getElementById('select_all').click();
	}
};